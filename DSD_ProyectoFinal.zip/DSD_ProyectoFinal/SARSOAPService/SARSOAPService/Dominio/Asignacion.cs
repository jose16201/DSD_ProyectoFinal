﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace SARSOAPService.Dominio
{
    [DataContract]
    public class Asignacion
    {
        [DataMember]
        public string nu_serie { get; set; }

      
        [DataMember]
        public int cod_colaborador { get; set; }

        [DataMember]
        public string fecha_asignacion { get; set; }

    }
}