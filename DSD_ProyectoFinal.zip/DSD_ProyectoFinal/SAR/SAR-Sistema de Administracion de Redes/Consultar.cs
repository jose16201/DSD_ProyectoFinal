﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAR_Sistema_de_Administracion_de_Redes
{
    public partial class Consultar : Form
    {
        EquiposService.EquiposClient obj = new EquiposService.EquiposClient();
        ServiceColaborador.ColaboradoresClient obj2 = new ServiceColaborador.ColaboradoresClient();
        
        public Consultar(string serie, string modelo, string caracteristica, string estado, string fecha)
        {
            InitializeComponent();
            
            textBox1.Text = serie;
            textBox3.Text = modelo;
            textBox2.Text = caracteristica;
            panel1.Visible = false;
            if (estado == "STK")
            {
                
                comboBox1.Text = "STOCK";
            }
            else if (estado == "ACT")
            {

                comboBox1.Text = "ACTIVO";
                panel1.Visible = true;
                EquiposService.Asignacion asignaciondetail = new EquiposService.Asignacion();
                ServiceColaborador.Colaborador objcolaborador = new ServiceColaborador.Colaborador();
                asignaciondetail = obj.ObtenerAsignacion(serie);
                textBox8.Text=asignaciondetail.fecha_asignacion;
                objcolaborador = obj2.ObtenerColaborador(asignaciondetail.cod_colaborador);
                textBox5.Text = objcolaborador.codigo.ToString();
                textBox6.Text = objcolaborador.nombre;
                textBox7.Text = objcolaborador.cargo;

            }
            else
            {
                comboBox1.Text = "BAJA";
            }

            dateTimePicker1.Text = fecha;
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Consultar.ActiveForm.Visible = false;
        }
    }
}
