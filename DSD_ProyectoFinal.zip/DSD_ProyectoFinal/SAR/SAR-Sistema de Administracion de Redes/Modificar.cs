﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SAR_Sistema_de_Administracion_de_Redes
{
    public partial class Modificar : Form
    {
        EquiposService.EquiposClient obj = new EquiposService.EquiposClient();
        ServiceColaborador.ColaboradoresClient obj2 = new ServiceColaborador.ColaboradoresClient();
        string estado1=null;
        public Modificar(string serie, string modelo, string caracteristica, string estado, string fecha)
        {
            InitializeComponent();
            textBox1.Text = serie;
            textBox3.Text = modelo;
            textBox2.Text = caracteristica;
            if(estado=="STK"){
                estado1 = "STK";
                comboBox1.Text = "STOCK";
            }
            else if (estado == "ACT")
            {
                
                comboBox1.Text = "ACTIVO";
            }
            else
            {
                comboBox1.Text = "BAJA";
            }

            dateTimePicker1.Text = fecha;
            /*  dateTimePicker1.Value   = DateTime.ParseExact(fecha + " 00:00:00,000", "dd/MM/yyyy HH:mm:ss,fff",
                                        System.Globalization.CultureInfo.InvariantCulture);
             dateTimePicker1.Focus();*/
        }

        private void Modificar_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Modificar.ActiveForm.Visible = false;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dateTimePicker1.MaxDate = DateTime.Now;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            EquiposService.Equipo objequipodetail = new EquiposService.Equipo();
            EquiposService.Asignacion asignaciondetail = new EquiposService.Asignacion();
            objequipodetail.Nu_serie = textBox1.Text;
            objequipodetail.Modelo = textBox3.Text;
            objequipodetail.Caracteris = textBox2.Text;
            if (comboBox1.Text == "STOCK")
            {
                objequipodetail.Estado = "STK";
            }
            else if (comboBox1.Text == "ACTIVO")
            {
                objequipodetail.Estado = "ACT";
            }
            else
            {
                objequipodetail.Estado = "BAJ";
            }

            
            objequipodetail.Fecha_compra = dateTimePicker1.Text;
            obj.ModificarEquipo(objequipodetail);
            if (estado1=="STK"||comboBox1.Text == "ACTIVO")
            {
                asignaciondetail.nu_serie = textBox1.Text;
                asignaciondetail.cod_colaborador = Int32.Parse(textBox5.Text);
                asignaciondetail.fecha_asignacion = textBox8.Text;
                obj.CrearAsignacion(asignaciondetail);
            }
            
            
            Form3 form3 = new Form3();
            form3.ReloadForm();
            form3.Refresh();
            form3.ListarEquipos();
            Form5.ActiveForm.Visible = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "ACTIVO")
            {
                panel1.Visible = true;
                
            }
            else 
            {
                panel1.Visible = false; 
            }
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ServiceColaborador.Colaborador objcolaborador = new ServiceColaborador.Colaborador();
            int m = Int32.Parse(textBox4.Text);
            objcolaborador = obj2.ObtenerColaborador(m);

            textBox5.Text=objcolaborador.codigo.ToString();
            textBox6.Text=objcolaborador.nombre;
            textBox7.Text=objcolaborador.cargo;
            textBox8.Text = DateTime.Now.ToString("dd/MM/yyyy");

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
